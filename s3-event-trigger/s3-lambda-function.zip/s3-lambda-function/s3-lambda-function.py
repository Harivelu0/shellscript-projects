import boto3
import json

def lambda_handler(event, context):
    sns = boto3.client('sns')
    
    # Get bucket name and object key from event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    
    # Create SNS topic if it doesn't exist
    topic_name = 's3-lambda-sns'
    topic_response = sns.create_topic(Name=topic_name)
    topic_arn = topic_response['TopicArn']
    
    # Publish to SNS
    message = f"New file uploaded: {key} in bucket {bucket}"
    sns.publish(
        TopicArn=topic_arn,
        Message=message,
        Subject='New S3 Upload'
    )
    
    return {
        'statusCode': 200,
        'body': json.dumps('Successfully processed S3 event')
    }
